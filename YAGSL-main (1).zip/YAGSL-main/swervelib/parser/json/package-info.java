/**
 * JSON Mapped classes for parsing configuration files.
 */
package swervelib.parser.json;
