/**
 * JSON Mapped Configuration types for modules.
 */
package swervelib.parser.json.modules;
